https://qiita.com/ku_a_i/items/93fdbd75edacb34ec610

https://b3s.be-s.co.jp/programming-language/python/5025/

https://qiita.com/dmikita/items/94899837d79925d89fae

https://chantastu.hatenablog.com/entry/2022/09/11/201402